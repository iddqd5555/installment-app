import 'dart:io';
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  final Dio _dio = Dio();
  final String baseUrl = 'http://192.168.1.41:8000/api';

  ApiService() {
    _dio.options.baseUrl = baseUrl;
    _dio.options.headers['Accept'] = 'application/json';
  }

  Future<String> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token') ?? '';
  }

  Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  Future<Map<String, dynamic>> getCurrentLocationMap() async {
    try {
      final pos = await Geolocator.getCurrentPosition();
      return {
        'latitude': pos.latitude,
        'longitude': pos.longitude,
        'isMocked': pos.isMocked,
      };
    } catch (_) {
      return {
        'latitude': null,
        'longitude': null,
        'isMocked': null,
      };
    }
  }

  Future<void> updateLocationSilently(double lat, double lng, bool isMocked) async {
    final token = await getToken();
    try {
      await _dio.post(
        '/user/update-location',
        data: {
          'lat': lat,
          'lng': lng,
          'is_mocked': isMocked,
        },
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
    } catch (e) {
      print('Update location error: $e');
    }
  }

  Future<String?> getPublicIP() async {
    // ใน production อาจจะยิงไป external service, ตรงนี้ mock ไว้ก่อน
    return '127.0.0.1';
  }

  Future<List<dynamic>> getInstallmentRequests() async {
    final token = await getToken();
    try {
      final gps = await getCurrentLocationMap();
      final publicIp = await getPublicIP();
      final response = await _dio.get(
        '/dashboard-data',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
        queryParameters: {
          'lat': gps['latitude'],
          'lng': gps['longitude'],
          'is_mocked': gps['isMocked'],
          'public_ip': publicIp,
        },
      );
      if (response.statusCode == 200 && response.data is List) {
        return response.data;
      }
      return [];
    } catch (e) {
      print('Get Dashboard Data Error: $e');
      return [];
    }
  }

  Future<Map<String, dynamic>> uploadSlip({
    int? installmentRequestId,
    List<String>? payForDates,
    required File slipFile,
  }) async {
    final token = await getToken();
    final gps = await getCurrentLocationMap();
    final publicIp = await getPublicIP();

    FormData formData = FormData();

    if (installmentRequestId != null) {
      formData.fields.add(MapEntry('installment_request_id', installmentRequestId.toString()));
    }

    if (payForDates != null && payForDates.isNotEmpty) {
      for (final date in payForDates) {
        formData.fields.add(MapEntry('pay_for_dates[]', date));
      }
    }

    formData.files.add(MapEntry('slip', await MultipartFile.fromFile(slipFile.path)));
    if (gps['latitude'] != null) formData.fields.add(MapEntry('lat', gps['latitude'].toString()));
    if (gps['longitude'] != null) formData.fields.add(MapEntry('lng', gps['longitude'].toString()));
    if (gps['isMocked'] != null) formData.fields.add(MapEntry('is_mocked', '${gps['isMocked']}'));
    if (publicIp != null) formData.fields.add(MapEntry('public_ip', publicIp));

    try {
      final response = await _dio.post(
        '/installment/pay',
        data: formData,
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
      if (response.statusCode == 200 && response.data['success'] == true) {
        return {'success': true, 'data': response.data};
      }
      return {'success': false, 'message': response.data['message'] ?? 'Unknown error'};
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  Future<dynamic> getDashboardData() async {
    final token = await getToken();
    final gps = await getCurrentLocationMap();
    final publicIp = await getPublicIP();
    try {
      final response = await _dio.get(
        '/dashboard-data',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
        queryParameters: {
          'lat': gps['latitude'],
          'lng': gps['longitude'],
          'is_mocked': gps['isMocked'],
          'public_ip': publicIp,
        },
      );
      return response.data;
    } catch (e) {
      print('Dashboard error: $e');
      return null;
    }
  }

  Future<bool> login(String phone, String password) async {
    try {
      final publicIp = await getPublicIP();
      final gps = await getCurrentLocationMap();
      final response = await _dio.post('/login', data: {
        'phone': phone,
        'password': password,
        'client_time': DateTime.now().toUtc().toIso8601String(),
        'public_ip': publicIp,
        'lat': gps['latitude'],
        'lng': gps['longitude'],
        'is_mocked': gps['isMocked'],
      });
      if (response.statusCode == 200 && response.data['token'] != null) {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('token', response.data['token']);
        print("TOKEN: ${response.data['token']}");
        return true;
      }
      return false;
    } catch (e) {
      print("Login error: $e");
      return false;
    }
  }

  String getImageUrl(String filename) {
    return '$baseUrl/storage/uploads/$filename';
  }

  // ---------------- Profile APIs ----------------

  Future<Map<String, dynamic>?> getProfile() async {
    final token = await getToken();
    try {
      final response = await _dio.get('/user/profile', options: Options(headers: {'Authorization': 'Bearer $token'}));
      return response.statusCode == 200 ? response.data : null;
    } catch (e) {
      print("Get profile error: $e");
      return null;
    }
  }

  Future<bool> updateProfile(Map<String, dynamic> data, {File? idCardImage}) async {
    final token = await getToken();
    try {
      FormData formData = FormData.fromMap(data);
      if (idCardImage != null) {
        formData.files.add(MapEntry('id_card_image', await MultipartFile.fromFile(idCardImage.path)));
      }
      final response = await _dio.post('/profile/update', data: formData, options: Options(headers: {'Authorization': 'Bearer $token'}));
      return response.statusCode == 200 && (response.data['success'] == true || response.data['status'] == true);
    } catch (e) {
      print("Update profile error: $e");
      return false;
    }
  }

  // ----------- ประวัติการชำระเงิน -----------
  Future<Map<String, dynamic>> getPaymentHistory(int installmentRequestId) async {
    final token = await getToken();
    final response = await _dio.get(
      '/installment/history',
      queryParameters: {'installment_request_id': installmentRequestId},
      options: Options(headers: {'Authorization': 'Bearer $token'}),
    );
    return response.data;
  }
}
