import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/api_service.dart';
import 'installment_dashboard_screen.dart';
import 'installment_payment_list_screen.dart';
import 'payment_screen.dart';
import 'profile_screen.dart';
import 'installments_screen.dart';

class DashboardScreen extends StatefulWidget {
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  final ApiService apiService = ApiService();

  bool isLoading = true;
  List<dynamic> contracts = [];
  dynamic selectedContract;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fetchInstallmentContracts();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchInstallmentContracts();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      fetchInstallmentContracts();
    }
  }

  Future<void> fetchInstallmentContracts() async {
    setState(() {
      isLoading = true;
    });
    final data = await apiService.getInstallmentRequests();
    setState(() {
      contracts = data;
      selectedContract = contracts.isNotEmpty ? contracts[0] : null;
      isLoading = false;
    });
  }

  Future<void> openPaymentScreen() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PaymentScreen(
          advancePayment: double.tryParse(selectedContract?['advance_payment']?.toString() ?? '0') ?? 0.0,
        ),
      ),
    );
    if (result == true) {
      await fetchInstallmentContracts();
    }
  }

  Color _danger(BuildContext ctx) => Theme.of(ctx).colorScheme.error;
  Color _primary(BuildContext ctx) => Theme.of(ctx).colorScheme.primary;
  Color _secondary(BuildContext ctx) => Theme.of(ctx).colorScheme.secondary;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Dashboard การผ่อนของคุณ',
          style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Theme.of(context).appBarTheme.titleTextStyle?.color ?? Colors.white, fontSize: 22),
        ),
        elevation: 0,
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        actions: [
          if (selectedContract != null)
            Padding(
              padding: const EdgeInsets.only(right: 18.0),
              child: Center(
                child: Text(
                  'คงเหลือ: ${(double.tryParse(selectedContract['advance_payment']?.toString() ?? '0') ?? 0).toStringAsFixed(2)} ฿',
                  style: GoogleFonts.prompt(
                    color: Colors.amberAccent, fontWeight: FontWeight.bold, fontSize: 15,
                  ),
                ),
              ),
            ),
          IconButton(
            icon: Icon(Icons.refresh, color: _secondary(context)),
            tooltip: 'Reload',
            onPressed: fetchInstallmentContracts,
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : contracts.isEmpty
              ? Center(child: Text("ไม่พบข้อมูลการผ่อนชำระ", style: GoogleFonts.prompt()))
              : RefreshIndicator(
                  onRefresh: fetchInstallmentContracts,
                  child: buildBodyByTab(),
                ),
    );
  }

  Widget buildBodyByTab() {
    final sc = selectedContract;
    if (sc == null) return Center(child: Text('ไม่พบข้อมูล', style: GoogleFonts.prompt()));
    double totalPaid = double.tryParse(sc['total_paid']?.toString() ?? '0') ?? 0.0;
    double totalAmount = double.tryParse(sc['total_installment_amount']?.toString() ?? '0') ?? 0.0;
    double outstanding = double.tryParse(sc['outstanding']?.toString() ?? '0') ?? 0.0;
    double dueToday = double.tryParse(sc['due_today']?.toString() ?? '0') ?? 0.0;
    int overdueCount = (sc['overdue_count'] as num?)?.toInt() ?? 0;
    int daysPassed = (sc['days_passed'] as num?)?.toInt() ?? 0;
    String nextPaymentDate = sc['next_payment_date'] ?? '-';
    int period = (sc['installment_period'] as num?)?.toInt() ?? 0;
    double percentPaid = totalAmount > 0 ? (totalPaid / totalAmount) * 100 : 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (contracts.length > 1)
            Container(
              margin: EdgeInsets.only(bottom: 14),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _secondary(context).withOpacity(.13), width: 1),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<dynamic>(
                  value: selectedContract,
                  isExpanded: true,
                  dropdownColor: Theme.of(context).cardColor,
                  style: GoogleFonts.prompt(color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white, fontWeight: FontWeight.w500),
                  icon: Icon(Icons.arrow_drop_down, color: _secondary(context)),
                  items: contracts
                      .map((c) => DropdownMenuItem<dynamic>(
                            value: c,
                            child: Text('สัญญา ${c['contract_number'] ?? c['id']}'),
                          ))
                      .toList(),
                  onChanged: (c) {
                    setState(() {
                      selectedContract = c;
                    });
                  },
                ),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 20,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            padding: EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.stars_rounded, color: _secondary(context), size: 28),
                    SizedBox(width: 8),
                    Text('เลขสัญญา ', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white)),
                    Text('${sc['contract_number'] ?? '-'}',
                        style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: _secondary(context), fontSize: 18)),
                  ],
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.attach_money_rounded, color: Colors.amber, size: 26),
                    SizedBox(width: 8),
                    Text('ผ่อนทอง: ', style: GoogleFonts.prompt(fontSize: 16, color: Colors.white70)),
                    Text('${sc['gold_amount'] ?? '-'} บาท', style: GoogleFonts.prompt(fontSize: 16, color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white)),
                  ],
                ),
                Divider(height: 32, thickness: 1, color: Colors.black12.withOpacity(0.13)),
                _dashboardInfoRow(Icons.event, 'งวดครบชำระวันนี้', '${dueToday.toStringAsFixed(2)} บาท', _primary(context)),
                _dashboardInfoRow(Icons.error_outline, 'ค้างชำระ (${overdueCount} งวด)', '${outstanding.toStringAsFixed(2)} บาท', _danger(context)),
                _dashboardInfoRow(Icons.calendar_month_rounded, 'วันครบกำหนดถัดไป', nextPaymentDate, _secondary(context)),
                _dashboardInfoRow(Icons.warning_amber_rounded, 'ค่าปรับสะสม', '${(double.tryParse(sc['total_penalty']?.toString() ?? '0') ?? 0).toStringAsFixed(2)} บาท', Colors.orange[700]!),
                Divider(height: 32, thickness: 1, color: Colors.black12.withOpacity(0.13)),
                Text('ชำระแล้วทั้งหมด', style: GoogleFonts.prompt(fontWeight: FontWeight.w600, color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white)),
                SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: LinearProgressIndicator(
                    value: totalAmount > 0 ? totalPaid / totalAmount : 0,
                    backgroundColor: Colors.white10,
                    color: Colors.greenAccent,
                    minHeight: 12,
                  ),
                ),
                SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    '${totalPaid.toStringAsFixed(2)} / ${totalAmount.toStringAsFixed(2)} บาท (${percentPaid.toStringAsFixed(2)}%)',
                    style: GoogleFonts.prompt(fontSize: 14, color: Colors.white60),
                  ),
                ),
                Divider(height: 32, thickness: 1, color: Colors.black12.withOpacity(0.13)),
                Text('ระยะเวลาผ่อน: $daysPassed / $period วัน',
                    style: GoogleFonts.prompt(fontWeight: FontWeight.w600, color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white)),
                SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: LinearProgressIndicator(
                    value: period > 0 ? daysPassed / period : 0,
                    backgroundColor: Colors.white10,
                    color: _secondary(context),
                    minHeight: 12,
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('${((daysPassed / (period == 0 ? 1 : period)) * 100).toStringAsFixed(2)}%',
                      style: GoogleFonts.prompt(fontSize: 14, color: Colors.white60)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _dashboardInfoRow(IconData icon, String title, String value, Color valueColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 22, color: valueColor),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.prompt(fontSize: 16, color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              style: GoogleFonts.prompt(fontSize: 16, fontWeight: FontWeight.bold, color: valueColor),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }
}
