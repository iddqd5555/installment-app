import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';

class PaymentHistoryScreen extends StatefulWidget {
  const PaymentHistoryScreen({super.key});

  @override
  State<PaymentHistoryScreen> createState() => _PaymentHistoryScreenState();
}

class _PaymentHistoryScreenState extends State<PaymentHistoryScreen> {
  final ApiService apiService = ApiService();
  bool isLoading = true;
  List<dynamic> payments = [];
  String? error;

  final int installmentRequestId = 1; // <<< เปลี่ยนเลข id ให้ตรง user จริง

  @override
  void initState() {
    super.initState();
    fetchPaymentHistory();
  }

  Future<void> fetchPaymentHistory() async {
    setState(() {
      isLoading = true;
      error = null;
    });
    try {
      final data = await apiService.getPaymentHistory(installmentRequestId);
      List<dynamic> items = data['history'] ?? [];
      final now = DateTime.now();
      payments = items.where((p) {
        final status = (p['payment_status'] ?? '').toString();
        final amt = double.tryParse(p['amount'].toString()) ?? 0;
        if (amt <= 0) return false;
        if (status == 'paid' || status == 'advance') return true;
        final dueStr = p['payment_due_date'];
        if (dueStr == null) return false;
        final due = DateTime.tryParse(dueStr);
        if (due == null) return false;
        return due.isBefore(DateTime(now.year, now.month, now.day).add(const Duration(days: 1)));
      }).toList();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  Widget _buildReceiptButton(String? receiptUrl) {
    if (receiptUrl == null || receiptUrl.isEmpty) return const SizedBox.shrink();
    return ElevatedButton.icon(
      icon: const Icon(Icons.receipt_long),
      label: const Text('ดูใบเสร็จ/ดาวน์โหลด'),
      onPressed: () {
        // Navigator.push หรือใช้ url_launcher (future)
      },
    );
  }

  Widget _buildPaymentCard(Map<String, dynamic> payment) {
    final status = payment['payment_status'] ?? '';
    final isPaid = status == 'paid' || status == 'advance';
    final dueDateStr = payment['payment_due_date'] ?? '';
    String dateDisplay = dueDateStr;
    try {
      final due = DateTime.tryParse(dueDateStr);
      if (due != null) {
        dateDisplay = DateFormat('yyyy-MM-dd').format(due);
      }
    } catch (_) {}
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      color: Theme.of(context).cardColor,
      child: ListTile(
        leading: Icon(isPaid ? Icons.check_circle : Icons.schedule, color: isPaid ? Colors.green : Colors.orange),
        title: Text("วันที่ $dateDisplay  •  ${payment['amount'] ?? '-'} บาท", style: GoogleFonts.prompt()),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (payment['amount_paid'] != null) Text("ชำระแล้ว: ${payment['amount_paid']} บาท", style: GoogleFonts.prompt()),
            if (payment['payment_proof'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Image.network(payment['payment_proof'], height: 90, fit: BoxFit.contain),
              ),
            if (payment['receipt_url'] != null)
              _buildReceiptButton(payment['receipt_url']),
          ],
        ),
        trailing: Text(
          isPaid ? 'ชำระแล้ว' : 'ค้างจ่าย',
          style: GoogleFonts.prompt(color: isPaid ? Colors.green : Theme.of(context).colorScheme.error, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ประวัติการชำระเงิน', style: GoogleFonts.prompt(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.bold))),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text('ผิดพลาด: $error', style: GoogleFonts.prompt(color: Theme.of(context).colorScheme.error)))
              : payments.isEmpty
                  ? Center(child: Text('ไม่มีประวัติการชำระเงิน', style: GoogleFonts.prompt()))
                  : ListView.builder(
                      itemCount: payments.length,
                      itemBuilder: (context, idx) => _buildPaymentCard(payments[idx] as Map<String, dynamic>),
                    ),
    );
  }
}
