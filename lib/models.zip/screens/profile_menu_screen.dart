import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'profile_detail_screen.dart';
import 'payment_history_screen.dart';
import '../services/api_service.dart';

class ProfileMenuScreen extends StatefulWidget {
  const ProfileMenuScreen({super.key});
  @override
  State<ProfileMenuScreen> createState() => _ProfileMenuScreenState();
}

class _ProfileMenuScreenState extends State<ProfileMenuScreen> {
  Map<String, dynamic>? profile;
  bool isLoading = true;
  final ApiService apiService = ApiService();

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    setState(() {
      isLoading = true;
    });
    final data = await apiService.getProfile();
    setState(() {
      profile = data;
      isLoading = false;
    });
  }

  Future<void> handleLogout() async {
    await apiService.clearToken();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  Color _danger(BuildContext ctx) => Theme.of(ctx).colorScheme.error;
  Color _secondary(BuildContext ctx) => Theme.of(ctx).colorScheme.secondary;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text("โปรไฟล์ของฉัน", style: GoogleFonts.prompt(color: _secondary(context), fontWeight: FontWeight.bold)),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: _secondary(context)),
            tooltip: 'Reload',
            onPressed: fetchProfile,
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: fetchProfile,
              child: ListView(
                children: [
                  if (profile != null) ...[
                    Container(
                      margin: const EdgeInsets.all(20),
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(.09),
                            blurRadius: 16,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${profile?['first_name'] ?? ""} ${profile?['last_name'] ?? ""}",
                            style: GoogleFonts.prompt(fontWeight: FontWeight.bold, fontSize: 19, color: _secondary(context)),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "เบอร์โทร: ${profile?['phone'] ?? ""}",
                            style: GoogleFonts.prompt(color: Colors.white70, fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                  ],
                  SizedBox(height: 8),
                  _profileMenuItem(
                    icon: Icons.person_rounded,
                    color: Colors.orange,
                    label: "แก้ไขข้อมูลส่วนตัว",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ProfileDetailScreen()),
                      ).then((v) => fetchProfile());
                    },
                  ),
                  _profileMenuItem(
                    icon: Icons.history,
                    color: Colors.blueAccent,
                    label: "ประวัติการชำระเงิน",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const PaymentHistoryScreen()),
                      );
                    },
                  ),
                  _profileMenuItem(
                    icon: Icons.assignment,
                    color: Colors.teal,
                    label: "ข้อตกลงการใช้งาน",
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          backgroundColor: Theme.of(context).cardColor,
                          title: Text("ข้อตกลงการใช้งาน", style: GoogleFonts.prompt(color: _secondary(context), fontWeight: FontWeight.bold)),
                          content: Text("...เนื้อหาข้อตกลง...", style: GoogleFonts.prompt(color: Colors.white70)),
                          actions: [
                            TextButton(
                              child: Text("ปิด", style: GoogleFonts.prompt(color: _secondary(context))),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  _profileMenuItem(
                    icon: Icons.privacy_tip,
                    color: Colors.green,
                    label: "นโยบายความเป็นส่วนตัว",
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          backgroundColor: Theme.of(context).cardColor,
                          title: Text("นโยบายความเป็นส่วนตัว", style: GoogleFonts.prompt(color: _secondary(context), fontWeight: FontWeight.bold)),
                          content: Text("...เนื้อหานโยบายความเป็นส่วนตัว...", style: GoogleFonts.prompt(color: Colors.white70)),
                          actions: [
                            TextButton(
                              child: Text("ปิด", style: GoogleFonts.prompt(color: _secondary(context))),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 8),
                  Divider(),
                  _profileMenuItem(
                    icon: Icons.logout,
                    color: _danger(context),
                    label: "ออกจากระบบ",
                    onTap: () async {
                      await handleLogout();
                    },
                    isLogout: true,
                  ),
                  SizedBox(height: 12),
                ],
              ),
            ),
    );
  }

  Widget _profileMenuItem({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 4, horizontal: 18),
      child: ListTile(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        tileColor: isLogout ? Theme.of(context).colorScheme.error.withOpacity(0.12) : Theme.of(context).cardColor,
        leading: Icon(icon, color: color, size: 27),
        title: Text(label, style: GoogleFonts.prompt(fontWeight: FontWeight.w600, color: isLogout ? Theme.of(context).colorScheme.error : Colors.white)),
        onTap: onTap,
      ),
    );
  }
}
