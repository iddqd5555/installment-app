import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_service.dart';

class PaymentScreen extends StatefulWidget {
  final double advancePayment;
  const PaymentScreen({super.key, this.advancePayment = 0.0});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  File? slipFile;
  bool isUploading = false;
  String? message;
  double advancePayment = 0.0;

  @override
  void initState() {
    super.initState();
    advancePayment = widget.advancePayment;
  }

  Future<void> pickSlip() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => slipFile = File(picked.path));
    }
  }

  Future<void> uploadSlip() async {
    if (slipFile == null || isUploading) return;
    setState(() {
      isUploading = true;
      message = null;
    });

    try {
      final result = await ApiService().uploadSlip(
        slipFile: slipFile!,
      );
      setState(() {
        isUploading = false;

        if (result['used'] == true) {
          message = "❌ สลิปนี้ถูกใช้งานแล้ว คุณไม่สามารถอัพโหลดสลิปซ้ำได้";
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("❌ สลิปนี้ถูกใช้งานแล้ว")),
          );
        } else if (result['success'] == true) {
          message = "อัปโหลดสลิปสำเร็จ กรุณารอปรับยอด";
          slipFile = null;
          advancePayment = double.tryParse(result['advance_payment'].toString()) ?? advancePayment;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("เติมเงินสำเร็จ! ยอดถูกอัปเดตแล้ว")),
          );
          if (Navigator.canPop(context)) {
            Navigator.pop(context, true); // บังคับ refresh dashboard
          }
        } else {
          message = "อัปโหลดล้มเหลว: ${result['message'] ?? "ไม่ทราบสาเหตุ"}";
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message!)),
          );
        }
      });
    } catch (e) {
      setState(() {
        isUploading = false;
        message = "เกิดข้อผิดพลาด: $e";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message!)),
      );
    }
  }

  Color _secondary(BuildContext ctx) => Theme.of(ctx).colorScheme.secondary;
  Color _danger(BuildContext ctx) => Theme.of(ctx).colorScheme.error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('การชำระเงิน (เติมเงิน)'),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            Card(
              elevation: 2,
              color: Theme.of(context).cardColor,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('📌 ข้อมูลบัญชีสำหรับเติมเงิน',
                      style: GoogleFonts.prompt(fontSize: 16, fontWeight: FontWeight.bold, color: _secondary(context))),
                    Divider(),
                    Text('ธนาคาร: กสิกรไทย', style: GoogleFonts.prompt(color: Theme.of(context).textTheme.bodyLarge?.color)),
                    Text('ชื่อบัญชี: บริษัท วิสดอม โกลด์ กรุ้ป จำกัด', style: GoogleFonts.prompt(color: Theme.of(context).textTheme.bodyLarge?.color)),
                    Text('เลขที่บัญชี: 865-1-00811-6', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Colors.amberAccent)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Icon(Icons.account_balance_wallet, color: Colors.blue),
                const SizedBox(width: 8),
                Text(
                  "ยอดเงินคงเหลือในระบบ: ${advancePayment.toStringAsFixed(2)} บาท",
                  style: GoogleFonts.prompt(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Text(
              "อัปโหลดสลิปโอนเงินเข้า บจก. (จะปรับยอดให้อัตโนมัติ)",
              style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color),
            ),
            const SizedBox(height: 10),
            slipFile == null
                ? Text("ยังไม่ได้เลือกรูปสลิป", style: GoogleFonts.prompt(color: Colors.grey))
                : Image.file(slipFile!, height: 180),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: isUploading ? null : pickSlip,
                    icon: const Icon(Icons.upload_file),
                    label: const Text("เลือกรูปสลิป"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _secondary(context),
                      textStyle: GoogleFonts.prompt(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: isUploading || slipFile == null ? null : uploadSlip,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      textStyle: GoogleFonts.prompt(fontWeight: FontWeight.bold),
                    ),
                    child: isUploading
                        ? const SizedBox(
                            width: 18, height: 18,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                          )
                        : const Text("ส่งสลิป"),
                  ),
                ),
              ],
            ),
            if (message != null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  message!,
                  style: GoogleFonts.prompt(
                    color: message!.contains("สำเร็จ") ? Colors.green : _danger(context),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
