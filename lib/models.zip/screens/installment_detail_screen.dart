import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class InstallmentDetailScreen extends StatelessWidget {
  final dynamic installment;

  const InstallmentDetailScreen({super.key, required this.installment});

  Color _danger(BuildContext ctx) => Theme.of(ctx).colorScheme.error;

  @override
  Widget build(BuildContext context) {
    final payments = installment['installment_payments'] ?? [];
    final contractNumber = installment['contract_number'] ?? "-";
    final goldAmount = installment['gold_amount']?.toString() ?? "-";
    final period = installment['installment_period']?.toString() ?? "-";
    final totalInstallment = installment['total_installment_amount']?.toString() ?? "-";
    final status = installment['status'] ?? "-";
    final paid = double.tryParse(installment['total_paid']?.toString() ?? '0') ?? 0.0;

    return Scaffold(
      appBar: AppBar(
        title: Text('รายละเอียดสัญญา $contractNumber', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary)),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Theme.of(context).cardColor,
            elevation: 3,
            margin: EdgeInsets.only(bottom: 14),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('เลขที่สัญญา: $contractNumber', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, fontSize: 16, color: Theme.of(context).colorScheme.secondary)),
                  Text('จำนวนทอง: $goldAmount บาท', style: GoogleFonts.prompt()),
                  Text('จำนวนวันผ่อน: $period วัน', style: GoogleFonts.prompt()),
                  Text('ยอดรวมที่ต้องผ่อน: $totalInstallment บาท', style: GoogleFonts.prompt()),
                  Text('สถานะสัญญา: $status', style: GoogleFonts.prompt()),
                  SizedBox(height: 6),
                  Text('ยอดชำระแล้ว: ${paid.toStringAsFixed(2)} บาท', style: GoogleFonts.prompt(color: Colors.green)),
                ],
              ),
            ),
          ),
          Text('⏳ งวดค้างชำระ', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Colors.orange[700])),
          ...(payments.where((p) => p['payment_status'] != 'paid').map((p) {
            final dueDate = p['payment_due_date'] ?? '-';
            final amount = double.tryParse('${p['amount'] ?? "0"}') ?? 0.0;
            return ListTile(
              leading: Icon(Icons.warning, color: Colors.orange),
              title: Text("ครบกำหนด: $dueDate", style: GoogleFonts.prompt()),
              subtitle: Text("ยอด: ${amount.toStringAsFixed(2)} บาท", style: GoogleFonts.prompt()),
              trailing: Text('ยังไม่จ่าย', style: GoogleFonts.prompt(color: _danger(context))),
            );
          }).toList()),
          Divider(height: 24, thickness: 1),
          Text('✅ ประวัติชำระงวด', style: GoogleFonts.prompt(fontWeight: FontWeight.bold, color: Colors.green[600])),
          ...(payments.where((p) => p['payment_status'] == 'paid').map((p) {
            final dueDate = p['payment_due_date'] ?? '-';
            final amount = double.tryParse('${p['amount'] ?? "0"}') ?? 0.0;
            final ref = p['ref'] ?? p['payment_number'] ?? p['slip_reference'] ?? '';
            return ListTile(
              leading: Icon(Icons.check_circle, color: Colors.green),
              title: Text("งวด $dueDate", style: GoogleFonts.prompt()),
              subtitle: Text("ยอด ${amount.toStringAsFixed(2)} บาท | อ้างอิง: $ref", style: GoogleFonts.prompt()),
            );
          }).toList()),
        ],
      ),
    );
  }
}
